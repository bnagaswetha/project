package com.capgemini.hbms.dao;

public interface QueryMapper {
	public static final String RETRIVE_ALL_MOBILES="SELECT * FROM mobiles";
	public static final String DELETE_MOBILE="DELETE FROM mobiles WHERE mobileid=?";
	public static final String QUERRY_MOBILE_RANGE="SELECT * FROM mobiles WHERE price >=? AND price <=?";
	public static final String CHECK_VALID_USER="SELECT * FROM users WHERE email=? and password=?";
	public static final String ADD_USER_DETAILS=
			"INSERT INTO users VALUES(userid_seq.NEXTVAL,?,?,?,?,?,?,?)";
	public static final String GET_PURCHASEID="SELECT purchaseid FROM purchasedetails WHERE phoneno=?";
	public static final String RETRIVE_MOBILE="SELECT * FROM mobiles WHERE mobileid=?";
	public static final String UPDATE_MOBILE_QUANTITY="UPDATE mobiles set quantity=quantity-? WHERE mobileid=?";
}
