package com.capgemini.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.capgemini.hbms.bean.Users;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.util.DBConnection;

public class UserRegistrationImpl implements IUserRegistration {

	@Override
	public boolean registerUser(Users user) throws HBMSException  {
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=
						connection.prepareStatement(QueryMapper.ADD_USER_DETAILS);


				){
			
			preparedStatement.setString(1,user.getPassword());
			preparedStatement.setString(2,user.getRole());
			preparedStatement.setString(3,user.getUser_name());
			preparedStatement.setString(4,user.getMobile_no());
			preparedStatement.setString(5,user.getPhone());
			preparedStatement.setString(6,user.getAddress());
			preparedStatement.setString(7,user.getEmail());


			int n=preparedStatement.executeUpdate();
			if(n>0){
				return true;
			}else
			{
				return false;
			}
				



		}catch(SQLException e){

			throw new HBMSException("Technical error refer log");
		}

	
	
}

}
