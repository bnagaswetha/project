package com.capgemini.hbms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.util.DBConnection;

public class BookingDaoImpl implements IBookingDao{

	@Override
	public Integer addBookingDetails(BookingDetails bookingDetails) throws HBMSException {
		try(Connection connection=DBConnection.getConnection();	
				PreparedStatement preparestatement=connection.prepareStatement(QueryMapper.ADD_BOOKING_DETAILS);
				PreparedStatement preparestatement1=connection.prepareStatement(QueryMapper.GET_BOOKING_ID);				
				){

			preparestatement.setInt(1,bookingDetails.getRoom_id());
			preparestatement.setInt(2,bookingDetails.getUser_id());
			preparestatement.setDate(3,Date.valueOf(bookingDetails.getBooked_from()));
			preparestatement.setDate(4,Date.valueOf(bookingDetails.getBooked_to()));
			preparestatement.setInt(5,bookingDetails.getNo_of_adults());
			preparestatement.setInt(6,bookingDetails.getNo_of_children());
			preparestatement.setDouble(7,bookingDetails.getAmount());
			
			preparestatement1.setInt(1, bookingDetails.getUser_id());
			
			int i=preparestatement.executeUpdate();
			if(i>0){

				ResultSet resultSet=preparestatement1.executeQuery();
				if(resultSet.next())
					return resultSet.getInt(1);
			}else{
				System.out.println("Unable to book");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}

}
