package com.capgemini.hbms.dao;

import com.capgemini.hbms.bean.Users;
import com.capgemini.hbms.exception.HBMSException;

public interface IUserDao {
	public boolean registerUser(Users user) throws HBMSException;
	public boolean checkValidUser(String email,String password) throws HBMSException;

}
