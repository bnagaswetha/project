package com.capgemini.hbms.dao;

import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.exception.HBMSException;

public interface IBookingDao {
	public Integer addBookingDetails(BookingDetails bookingDetails) throws HBMSException;

}
