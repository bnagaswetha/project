package com.capgemini.hbms.service;

import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.exception.HBMSException;

public interface IBookingService {
	public Integer addBookingDetails(BookingDetails bookingDetails) throws HBMSException;

}
