package com.capgemini.hbms.service;

import com.capgemini.hbms.bean.Users;
import com.capgemini.hbms.dao.IUserDao;
import com.capgemini.hbms.dao.UserDaoImpl;
import com.capgemini.hbms.exception.HBMSException;

public class UserServiceImpl implements IUserService {
	IUserDao userDao=new UserDaoImpl();

	@Override
	public boolean registerUser(Users user) throws HBMSException {
		
		return userDao.registerUser(user);
	}

	@Override
	public boolean checkValidUser(String email, String password)
			throws HBMSException {
		
		return userDao.checkValidUser(email, password);
	}

}
