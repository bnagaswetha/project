package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.Room;
import com.capgemini.hbms.exception.HBMSException;

public interface IRoomService {

	Boolean addRoomDetails(Room room) throws HBMSException;

	void deleteRoomDetails(Integer hotelId1, String roomNo1) throws HBMSException;

	List<Room> displayRoomDetails() throws HBMSException;

	List<Room> displayRoomDetails(int hotel_id) throws HBMSException;


}
