package com.capgemini.hbms.service;

import com.capgemini.hbms.bean.Users;
import com.capgemini.hbms.exception.HBMSException;

public interface IUserRegistrationService {
	public boolean registerUser(Users user) throws HBMSException;

}
