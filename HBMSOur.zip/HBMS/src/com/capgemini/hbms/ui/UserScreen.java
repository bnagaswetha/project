package com.capgemini.hbms.ui;

import java.util.Scanner;

import com.capgemini.hbms.bean.Users;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.service.IUserService;
import com.capgemini.hbms.service.UserServiceImpl;

public class UserScreen {
	public static IUserService userService=new UserServiceImpl();
	public static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("HBMS Application");
		System.out.println("1.Register\n 2.Login");
		int choice=sc.nextInt();
		switch(choice){
		case 1:     registerUser();
					break;
		case 2:     checkValidUser();
					break;
		}
		
		
		
		

	}

	private static void checkValidUser() {
		System.out.println("Enter your email");
		String email=sc.next();
		System.out.println("Enter your password");
		String password=sc.next();
		try {
			if(userService.checkValidUser(email, password)){
				System.out.println("you are valid user ");
			}
			else{
				System.out.println("you are invalid user");
			}
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	private static boolean registerUser()  {
		
		System.out.println("Enter your name");
		String user_name=sc.next();
		System.out.println("Enter your role");
		String role=sc.next();
		System.out.println("Enter your mobile number");
		String mobile_no=sc.next();
		System.out.println("Enter your phone");
		String phone=sc.next();
		System.out.println("Enter your address");
		String address=sc.next();
		System.out.println("Enter your password");
		String password=sc.next();
		System.out.println("Enter your email");
		String email=sc.next();
		Users user=new Users();
		user.setAddress(address);
		user.setEmail(email);
		user.setMobile_no(mobile_no);
		user.setPassword(password);
		user.setPhone(phone);
		user.setRole(role);
		user.setUser_name(user_name);
		try {
			if(userService.registerUser(user))
			{
				System.out.println("Registration Completed successfully");
			}
			else{
				System.out.println("Unable to register");
			}
		} catch (HBMSException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return false;
		
		
		
	}

}
