package com.capgemini.hbms.ui;

import java.util.Scanner;

public class HomeScreen {
	public static Scanner sc=new Scanner(System.in);
	static UserScreen userScreen=new UserScreen();
	static AdminScreen adminScreen=new AdminScreen();

	
	public static void main(String[] args) {
		System.out.println("HBMS Application");
		System.out.println("1.Register\n 2.Login");
		int choice=sc.nextInt();
		switch(choice){
		case 1:     userScreen.registerUser();
					break;
					
		case 2:    System.out.println("1.Admin\n 2.User/HotelEmployee");
				   int choice1=sc.nextInt();
				   switch(choice1){
				   case 2:if(userScreen.checkValidUser()){
						  System.out.println("1.Search Hotels");
						  System.out.println("2.Book Hotels");
						  System.out.println("3.View Booking Status");
						  int choice2=sc.nextInt();
						  switch(choice2){
						  case 1:
							  adminScreen.displayHotelDetails();
							break;
							
						  case 2:
							  System.out.println("Booking Id:"+userScreen.addBookingDetails());
							break;
							
						  case 3:
							break;
						  }
				
						}
				   break;
				   case 1:
					   if(adminScreen.checkValidAdmin()){
						   System.out.println("1.Add Hotels");
						   System.out.println("2.Delete Hotel");
						   System.out.println("3.View List of  Hotels");
						   System.out.println("4.Add Room");
						   System.out.println("5.Delete Room");
						   
						   int ch=sc.nextInt();
						   switch(ch){
						   case 1:if(adminScreen.addHotelDetails())
							   		   System.out.println("succece");
						   break;
						   case 2:adminScreen.deleteHotelDetails();
						   break;
						   case 3:adminScreen.displayHotelDetails();
						   break;
						   case 4:adminScreen.addRoom();
						   break;
				 		   case 5:adminScreen.deleteRoom();;
						   break;
						
						   }
					   }else{
						   System.out.println("In Valid");
						   
					   }
					   break;
				   
				   }
			
					
					break;
		}
		
		
		
		

	}
}
